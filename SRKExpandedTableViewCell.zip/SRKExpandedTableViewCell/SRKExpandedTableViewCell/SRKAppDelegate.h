//
//  AppDelegate.h
//  SRKExpandedTableViewCell
//
//  Created by Kumar on 26/05/16.
//  Copyright © 2016 Kumar. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SRKAppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

