//
//  main.m
//  SRKExpandedTableViewCell
//
//  Created by Kumar on 26/05/16.
//  Copyright © 2016 Kumar. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "SRKAppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([SRKAppDelegate class]));
    }
}
