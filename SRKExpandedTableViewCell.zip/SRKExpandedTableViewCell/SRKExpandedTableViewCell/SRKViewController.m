//
//  ViewController.m
//  SRKExpandedTableViewCell
//
//  Created by Shashi Ranjan Kumar on 26/05/16.
//  Copyright © 2016 Shashi Ranjan Kumar. All rights reserved.

// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
//
// The above copyright notice and this permission notice shall be included in
// all copies or substantial portions of the Software.
//
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
// THE SOFTWARE.
#import "SRKViewController.h"
#import "SRKExpandableCell.h"

@interface SRKViewController ()<UITableViewDelegate,UITableViewDataSource>
{
    NSMutableArray *titleArray;
    NSArray *subtitleArray;
    NSArray *textArray;
    NSInteger isExpanded;
}
@property (strong, nonatomic) IBOutlet UITableView *myTableView;

@end

@implementation SRKViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
    isExpanded=-1;
    titleArray=[NSMutableArray new];
    NSString *string;
    
    for(int i=0;i<8;i++)
    {
        string=[[NSString alloc]initWithFormat:@"Row %i",i];
        [titleArray addObject:string];
    }
    subtitleArray=[NSArray arrayWithObjects:@"First row",@"Second Row",@"Third Row",@"Fourth Row",@"Fifth Row",@"Sixth Row",@"Seventh Row",@"Eight Row", nil];
    
    textArray=[NSArray arrayWithObjects:@"Apple",@"Mango",@"Banana",@"Goava",@"Orange",@"Cocoanut",@"Apple",@"Orange", nil];
}
-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;
}
-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return  titleArray.count;
}
-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    SRKExpandableCell *cell=(SRKExpandableCell *)[self.myTableView dequeueReusableCellWithIdentifier:@"cell"];
    if(cell==nil)
    {
        NSArray *nib=[[NSBundle mainBundle]loadNibNamed:@"SRKExpandableCell" owner:self options:nil];
        cell=[nib objectAtIndex:0];
        
    }
    
    if(isExpanded==indexPath.row)
    {
        cell.contentView.backgroundColor=[UIColor grayColor];
        cell.titleLabel.textColor=[UIColor whiteColor];
        cell.fruitTitlelabel.textColor=[UIColor whiteColor];
        cell.fruitLabel.textColor=[UIColor whiteColor];
        cell.valueLabel.textColor=[UIColor whiteColor];
        cell.calculationLabel.textColor=[UIColor whiteColor];
        cell.subTitleLabe.textColor=[UIColor whiteColor];

    }
    else
    {
        cell.contentView.backgroundColor=[UIColor whiteColor];
    }
    cell.titleLabel.text=[titleArray objectAtIndex:indexPath.row];
    cell.subTitleLabe.text=[subtitleArray objectAtIndex:indexPath.row];
    cell.fruitTitlelabel.text=[textArray objectAtIndex:indexPath.row];
    cell.valueLabel.text=[NSString stringWithFormat:@"%ld",(indexPath.row+1)*25];
    return cell;
}
-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    if(isExpanded==indexPath.row)
    {
        return 100;
    }
    else
    {
        return 44;
    }
}
-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    if(isExpanded==indexPath.row)
    {
        isExpanded=-1;
        [_myTableView reloadRowsAtIndexPaths:[NSArray arrayWithObject:indexPath] withRowAnimation:UITableViewRowAnimationFade];
        return;
    }
    if(isExpanded==-1)
    {
        NSIndexPath *prevPath=[NSIndexPath indexPathForRow:isExpanded inSection:0];
        isExpanded=indexPath.row;
        [_myTableView reloadRowsAtIndexPaths:[NSArray arrayWithObject:prevPath] withRowAnimation:UITableViewRowAnimationFade];
       
    }
    isExpanded=indexPath.row;
    
    [self.myTableView reloadRowsAtIndexPaths:[NSArray arrayWithObject:indexPath] withRowAnimation:UITableViewRowAnimationFade];
    
}




@end